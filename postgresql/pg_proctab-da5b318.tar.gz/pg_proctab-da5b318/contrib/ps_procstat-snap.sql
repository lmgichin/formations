BEGIN;
SELECT ps_snap_stats(NULL);
COMMIT;
